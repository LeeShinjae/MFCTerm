
// MFCApplication24View.cpp : CMFCApplication24View Ŭ������ ����
//

#include "stdafx.h"
// SHARED_HANDLERS�� �̸� ����, ����� �׸� �� �˻� ���� ó���⸦ �����ϴ� ATL ������Ʈ���� ������ �� ������
// �ش� ������Ʈ�� ���� �ڵ带 �����ϵ��� �� �ݴϴ�.
#ifndef SHARED_HANDLERS
#include "MFCApplication24.h"
#endif

#include "MFCApplication24Doc.h"
#include "MFCApplication24View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMFCApplication24View

IMPLEMENT_DYNCREATE(CMFCApplication24View, CView)

BEGIN_MESSAGE_MAP(CMFCApplication24View, CView)
	ON_WM_PAINT()
END_MESSAGE_MAP()

// CMFCApplication24View ����/�Ҹ�

CMFCApplication24View::CMFCApplication24View()
{
	// TODO: ���⿡ ���� �ڵ带 �߰��մϴ�.

}

CMFCApplication24View::~CMFCApplication24View()
{
}

BOOL CMFCApplication24View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs�� �����Ͽ� ���⿡��
	//  Window Ŭ���� �Ǵ� ��Ÿ���� �����մϴ�.

	return CView::PreCreateWindow(cs);
}

// CMFCApplication24View �׸���

void CMFCApplication24View::OnDraw(CDC* /*pDC*/)
{
	CMFCApplication24Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: ���⿡ ���� �����Ϳ� ���� �׸��� �ڵ带 �߰��մϴ�.
}


// CMFCApplication24View ����

#ifdef _DEBUG
void CMFCApplication24View::AssertValid() const
{
	CView::AssertValid();
}

void CMFCApplication24View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMFCApplication24Doc* CMFCApplication24View::GetDocument() const // ����׵��� ���� ������ �ζ������� �����˴ϴ�.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMFCApplication24Doc)));
	return (CMFCApplication24Doc*)m_pDocument;
}
#endif //_DEBUG


// CMFCApplication24View �޽��� ó����


void CMFCApplication24View::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	dc.Rectangle(800, 20, 1155, 110); // ��ȣ��
	dc.Rectangle(800, 140, 1155, 230);//������ ��ȣ��
	dc.Rectangle(800, 420, 1155, 510); // ��ȣ��
	dc.Rectangle(800, 540, 1155, 630);//������ ��ȣ��
	CBrush brush1(RGB(0, 0, 0));
	dc.SelectObject(&brush1);
	dc.Ellipse(810, 30, 880, 100);
	CBrush brush2(RGB(0, 0, 0));
	dc.SelectObject(&brush2);
	dc.Ellipse(900, 30, 970, 100);
	CBrush brush3(RGB(0, 0, 0));
	dc.SelectObject(&brush3);
	dc.Ellipse(990, 30, 1060, 100);

	int R = 1;
	int Y = 1;
	int B = 1;
	int Person = 1;
	int Stop = 1;
	int Walk = 1;
	int Car = 1;

	if (R == 1)
	{
		CBrush brush4(RGB(255, 0, 0));
		dc.SelectObject(&brush4);
		dc.Ellipse(990, 30, 1060, 100);
	}
	if (Y == 1)
	{
		CBrush brush5(RGB(255, 204, 0));
		dc.SelectObject(&brush5);
		dc.Ellipse(900, 30, 970, 100);
	}
	if (B == 1)
	{
		CBrush brush6(RGB(51, 0, 204));
		dc.SelectObject(&brush6);
		dc.Ellipse(810, 30, 880, 100);
	}
	if (Person == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmapW(IDB_BITMAP1);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(1070, 28, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}

	if (Stop == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmapW(IDB_STOP);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(830, 146, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}
	if (Walk == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmapW(IDB_Walk);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(930, 146, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}

	if (Car == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmapW(IDB_CAR);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(1040, 146, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}

	////////////////////////////////////////////////////////////////////////////////////



	CBrush brush7(RGB(0, 0, 0));
	dc.SelectObject(&brush7);
	dc.Ellipse(810, 430, 880, 500);
	CBrush brush8(RGB(0, 0, 0));
	dc.SelectObject(&brush8);
	dc.Ellipse(900, 430, 970, 500);
	CBrush brush9(RGB(0, 0, 0));
	dc.SelectObject(&brush9);
	dc.Ellipse(990, 430, 1060, 500);

	int R1 = 1;
	int Y1 = 1;
	int B1 = 1;
	int Person1 = 1;
	int Stop1 = 1;
	int Walk1 = 1;
	int Car1 = 1;

	if (R1 == 1)
	{
		CBrush brush10(RGB(255, 0, 0));
		dc.SelectObject(&brush10);
		dc.Ellipse(990, 430, 1060, 500);
	}
	if (Y1 == 1)
	{
		CBrush brush11(RGB(255, 204, 0));
		dc.SelectObject(&brush11);
		dc.Ellipse(900, 430, 970, 500);
	}
	if (B1 == 1)
	{
		CBrush brush12(RGB(51, 0, 204));
		dc.SelectObject(&brush12);
		dc.Ellipse(810, 430, 880, 500);
	}
	if (Person1 == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmapW(IDB_BITMAP1);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(1070, 428, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}

	if (Stop1 == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmapW(IDB_STOP);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(830, 546, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}
	if (Walk1 == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmapW(IDB_Walk);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(930, 546, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}

	if (Car1 == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmapW(IDB_CAR);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(1040, 546, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}


}
