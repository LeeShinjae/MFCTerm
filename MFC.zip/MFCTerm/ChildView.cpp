﻿
// ChildView.cpp: CChildView 클래스의 구현
//

#include "stdafx.h"
#include "MFCTerm.h"
#include "ChildView.h"
#include "MFCTermProject.h"
#include "SharedImageBuffer.h"

#include <opencv2\opencv.hpp>
#include <opencv2\core\types_c.h>
#include <opencv2\highgui\highgui_c.h>
#include <iostream>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace cv;
using namespace std;

// CChildView
CChildView::CChildView()
{
	m_button = 0;
	OnTimerFlag = 0;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_WM_DRAWITEM()
	ON_COMMAND(ID_FILE_OPEN, &CChildView::OnFileOpen)
	ON_WM_LBUTTONDOWN()
	ON_WM_TIMER()
	ON_COMMAND(ID_FLIE_FINISH, &CChildView::OnFlieFinish)
	ON_COMMAND(ID_DISPLAY_HUMAN, &CChildView::OnDisplayHuman)
	ON_COMMAND(ID_DISPLAY_CAR, &CChildView::OnDisplayCar)
	ON_COMMAND(ID_DISPLAY_VOICE, &CChildView::OnDisplayVoice)
//	ON_COMMAND(ID_DISPLAY_HUMAN_COUNT, &CChildView::OnDisplayHumanCount)
	ON_UPDATE_COMMAND_UI(ID_DISPLAY_CAR, &CChildView::OnUpdateDisplayCar)
	ON_UPDATE_COMMAND_UI(ID_DISPLAY_HUMAN, &CChildView::OnUpdateDisplayHuman)
	ON_UPDATE_COMMAND_UI(ID_DISPLAY_HUMAN_COUNT, &CChildView::OnUpdateDisplayHumanCount)
	ON_COMMAND(ID_DISPLAY_LIGHTTIMER, &CChildView::OnDisplayLighttimer)
	ON_UPDATE_COMMAND_UI(ID_DISPLAY_LIGHTTIMER, &CChildView::OnUpdateDisplayLighttimer)
	ON_UPDATE_COMMAND_UI(ID_DISPLAY_VOICE, &CChildView::OnUpdateDisplayVoice)
	ON_COMMAND(ID_DISPLAY_HUMAN_COUNT, &CChildView::OnDisplayHumanCount)
END_MESSAGE_MAP()



// CChildView 메시지 처리기

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS,
		::LoadCursor(nullptr, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1), nullptr);

	return TRUE;
}
CString OnPain_str[10];
INT d_number;
INT i2 = 0;
INT H_NUM = 0;
INT C_NUM = 0;
BOOL DISPLY_FLAG_HUMAN = FALSE;
BOOL DISPLY_FLAG_CAR = FALSE;
BOOL DISPLY_FLAG_HUMANCOUNT = FALSE;
BOOL DISPLY_FLAG_LIGHTTIMER = FALSE;
BOOL DISPLY_FLAG_VOICE = FALSE;
INT DISPLAY_INDEX=1;
void CChildView::OnPaint()
{
	CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.

	dc.Rectangle(800, 20, 1155, 110); // 신호등
	dc.Rectangle(800, 140, 1155, 230);//보행자 신호등
	dc.Rectangle(800, 420, 1155, 510); // 신호등
	dc.Rectangle(800, 540, 1155, 630);//보행자 신호등
	CBrush brush1(RGB(0, 0, 0));
	dc.SelectObject(&brush1);
	dc.Ellipse(810, 30, 880, 100);
	CBrush brush2(RGB(0, 0, 0));
	dc.SelectObject(&brush2);
	dc.Ellipse(900, 30, 970, 100);
	CBrush brush3(RGB(0, 0, 0));
	dc.SelectObject(&brush3);
	dc.Ellipse(990, 30, 1060, 100);

	int R = 1;
	int Y = 1;
	int B = 1;
	int Person = 1;
	int Stop = 1;
	int Walk = 1;
	int Car = 1;

	if (R == 1)
	{
		CBrush brush4(RGB(255, 0, 0));
		dc.SelectObject(&brush4);
		dc.Ellipse(990, 30, 1060, 100);
	}
	if (Y == 1)
	{
		CBrush brush5(RGB(255, 204, 0));
		dc.SelectObject(&brush5);
		dc.Ellipse(900, 30, 970, 100);
	}
	if (B == 1)
	{
		CBrush brush6(RGB(51, 0, 204));
		dc.SelectObject(&brush6);
		dc.Ellipse(810, 30, 880, 100);
	}
	if (Person == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmap(IDB_PERSON);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(1070, 28, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}

	if (Stop == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmap(IDB_STOP);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(830, 146, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}
	if (Walk == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmap(IDB_WALK);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(930, 146, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}

	if (Car == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmap(IDB_CAR);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(1040, 146, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}

	////////////////////////////////////////////////////////////////////////////////////



	CBrush brush7(RGB(0, 0, 0));
	dc.SelectObject(&brush7);
	dc.Ellipse(810, 430, 880, 500);
	CBrush brush8(RGB(0, 0, 0));
	dc.SelectObject(&brush8);
	dc.Ellipse(900, 430, 970, 500);
	CBrush brush9(RGB(0, 0, 0));
	dc.SelectObject(&brush9);
	dc.Ellipse(990, 430, 1060, 500);

	int R1 = 1;
	int Y1 = 1;
	int B1 = 1;
	int Person1 = 1;
	int Stop1 = 1;
	int Walk1 = 1;
	int Car1 = 1;

	if (R1 == 1)
	{
		CBrush brush10(RGB(255, 0, 0));
		dc.SelectObject(&brush10);
		dc.Ellipse(990, 430, 1060, 500);
	}
	if (Y1 == 1)
	{
		CBrush brush11(RGB(255, 204, 0));
		dc.SelectObject(&brush11);
		dc.Ellipse(900, 430, 970, 500);
	}
	if (B1 == 1)
	{
		CBrush brush12(RGB(51, 0, 204));
		dc.SelectObject(&brush12);
		dc.Ellipse(810, 430, 880, 500);
	}
	if (Person1 == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmap(IDB_PERSON);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(1070, 428, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}

	if (Stop1 == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmap(IDB_STOP);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(830, 546, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}
	if (Walk1 == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmap(IDB_WALK);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(930, 546, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}

	if (Car1 == 1)
	{
		CDC MemDC;
		BITMAP bmpInfo;
		MemDC.CreateCompatibleDC(&dc);
		CBitmap bmp;
		CBitmap* pOldBmp = NULL;
		bmp.LoadBitmap(IDB_CAR);
		bmp.GetBitmap(&bmpInfo);
		pOldBmp = MemDC.SelectObject(&bmp);
		dc.BitBlt(1040, 546, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY);
		MemDC.SelectObject(pOldBmp);
	}


	// 그리기 메시지에 대해서는 CWnd::OnPaint()를 호출하지 마십시오.

	CFont font_heavy;
	// 글자 두께 두껍게, index number
	font_heavy.CreateFont(35,         // 글자높이
		15,                     // 글자너비
		0,                      // 출력각도
		0,                      // 기준 선에서의각도
		FW_HEAVY,               // 글자굵기
		FALSE,                  // Italic 적용여부
		FALSE,                  // 밑줄적용여부
		FALSE,                  // 취소선적용여부
		DEFAULT_CHARSET,        // 문자셋종류
		OUT_DEFAULT_PRECIS,     // 출력정밀도
		CLIP_DEFAULT_PRECIS,    // 클리핑정밀도
		DEFAULT_QUALITY,        // 출력문자품질
		DEFAULT_PITCH,          // 글꼴Pitch
		_T("굴림체")            // 글꼴
	);
	dc.SelectObject(&font_heavy);
	DISPLAY_INDEX = 1;
	if (DISPLY_FLAG_HUMAN == TRUE)
	{
		dc.TextOut(1300, 100 + DISPLAY_INDEX * 50, OnPain_str[0]);	// 사람
		DISPLAY_INDEX++;
	}
	if (DISPLY_FLAG_CAR == TRUE)
	{
		dc.TextOut(1300, 100 + DISPLAY_INDEX * 50, OnPain_str[1]);	// 차량
		DISPLAY_INDEX++;
	}
	if (DISPLY_FLAG_HUMANCOUNT == TRUE)
	{
		dc.TextOut(1300, 100 + DISPLAY_INDEX * 50, OnPain_str[2]);	// 사람수
		DISPLAY_INDEX++;
	}
	if (DISPLY_FLAG_LIGHTTIMER == TRUE)
	{
		OnPain_str[3] = _T("신호등 정보"); 
		dc.TextOut(1300, 100 + DISPLAY_INDEX * 50, OnPain_str[3]);	// 신호등정보
		DISPLAY_INDEX++;
		OnPain_str[4] = _T("초록불 정규시간 : "); // 타이머 부분에 넣으면 될것
		dc.TextOut(1300, 100 + DISPLAY_INDEX * 50, OnPain_str[4]);	// 신호등정보
		DISPLAY_INDEX++;
		OnPain_str[5] = _T("초록출 지연시간 : ");
		dc.TextOut(1300, 100 + DISPLAY_INDEX * 50, OnPain_str[5]);	// 신호등정보
		DISPLAY_INDEX++;
	}

	if (DISPLY_FLAG_VOICE == TRUE)
	{
		OnPain_str[6] = _T("음성 출력 중"); // 음성 함수에 넣어도 될 부분
		dc.TextOut(1300, 100 + DISPLAY_INDEX * 50, OnPain_str[6]);	// 음성 출력
	}


}


int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  여기에 특수화된 작성 코드를 추가합니다.

	return 0;
}


void CChildView::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CWnd::OnDrawItem(nIDCtl, lpDrawItemStruct);
}


void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CWnd::OnLButtonDown(nFlags, point);
	m_button = !m_button;
	if (m_button == 1) {
		SetTimer(1, 1, NULL);
	}
	else {
		KillTimer(1);
		OnTimerFlag = 0;
	}
}


void CChildView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if (nIDEvent == 1) {
		OnTimerFlag = 1;
	}

	CWnd::OnTimer(nIDEvent);
}


// 메뉴에서 '파일 > 불러오기'를 눌렀을 때
void CChildView::OnFileOpen()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	struct shm_remove
	{
		shm_remove() { shared_memory_object::remove("ODSharedMemory"); }
		~shm_remove() { shared_memory_object::remove("ODSharedMemory"); }
	} remover;

	//declare var
	ti t;

	do {
		t.cam.vc.open("D:\\MFC\\Video\\_횡단시뮬.mp4");
		//std::cout << "Try VideoCapture Open" << std::endl << std::endl;
	} while (!t.cam.vc.isOpened());

	t.cam.vc >> t.cam.image;

	//parameter check
	int nchs = t.cam.image.channels();
	//std::cout << "\tchannel:" << nchs << std::endl;
	if (nchs != 3 && nchs != 4) {
		t.cam.vc.release();
		getchar();
	}

	int dsz = t.cam.image.rows * t.cam.image.step;

	//Create a new segment with given name and size
	managed_shared_memory segment(create_only, "ODSharedMemory", dsz * 20);

	//allocation 
	t.od = (odi*)segment.allocate(sizeof(odi));
	assert(t.od != NULL);

	//set image size
	t.od->dsz = dsz;
	t.od->iHeight = t.cam.image.size().height;
	t.od->iWidth = t.cam.image.size().width;

	//std::cout << " od dsz   : " << t.od->dsz << std::endl;

	// check allocation , SIB
	assert(&t.od->SIBimage != NULL);

	//SIB allocation, get handle
	for (int i = 0; i < 2; i++) {
		t.od->SIBimage[i]._pMem = segment.allocate(dsz * 3);
		assert(&t.od->SIBimage[i]._pMem != NULL);
		t.od->SIBimage[i]._hMem = segment.get_handle_from_address(t.od->SIBimage[i]._pMem);
		assert(&t.od->SIBimage[i]._hMem != NULL);
	}
	//initial data copy
	memcpy(t.od->SIBimage[0]._pMem, t.cam.image.data, dsz);
	memcpy(t.od->SIBimage[1]._pMem, t.cam.image.data, dsz);

	// get handle
	managed_shared_memory::handle_t handle = segment.get_handle_from_address(t.od);

	//execute
	std::stringstream s;
	char odc_fn[] = "MFCodclient.exe";

	s << odc_fn << " " << handle << " " << t.od << std::ends;
	//std::cout << "Main cmd: " << s.str() << std::endl;

	//for ODector, initial parameter setting
	t.od->nDetections = 0;
	t.od->init_flag = false;
	t.od->index = 0;
	t.od->frame_full = false;
	t.od->ready_flag = false;
	t.od->run_flag = false;

	//RUN
	//std::cout << "\t\tinitialize od\n";
	thread p1(program_thread, std::ref(s));

	while (!t.od->init_flag) boost::detail::Sleep(100);

	thread p2(_camera, std::ref(t));

	cv::Mat image, result;

	int nDetections;
	std::vector<cv::Rect> boxes;
	std::vector<float> scores;
	std::vector<int> classes;


#define person
	//#define object
	while (1) {
		INT H_NUM = 0;
		INT C_NUM = 0;
		m_image = cv::Mat(t.cam.image);
		if (t.od->run_flag) {
			for (int i = 0; i < t.od->nDetections; i++) {
				if (t.od->classes[i] == 1)
				{
					H_NUM++;
				}
				else if (t.od->classes[i] == 3)
				{
					C_NUM++;
				}
				//std::cout
				//   << "classes: " << t.od->classes[i] << "\t"
				//   << "scores : " << t.od->scores[i] << "\t"
				//   << "boxes  : " << t.od->boxes[i].x << "\t" << t.od->boxes[i].y << "\t"
				//   << t.od->boxes[i].width << "\t" << t.od->boxes[i].height
				//   << std::endl;
/*
#ifdef person
				
				if (t.od->classes[i] == 1) {
					cv::rectangle(m_image, t.od->boxes[i], cv::Scalar(0, 0, 255), 2);
				}
				
#endif
*/
				cv::rectangle(m_image, t.od->boxes[i], cv::Scalar(0, 0, 255), 2);
#ifdef object 
				if (t.od->classes[i] < 70 && t.od->classes[i] != 1) {
					cv::rectangle(image, t.od->boxes[i], cv::Scalar(0, 0, 255), 2);
				}
#endif
			}				// -- 출력 부분 -- //
			if (H_NUM != 0)
			{
				OnPain_str[0].Format(_T("도로위 사람 수 : %d        "), H_NUM);
			}
			else
			{
				OnPain_str[0] = _T("사람 접근 없음            ");
			}
			if (C_NUM != 0)
			{
				OnPain_str[1].Format(_T("차량 접근 !!        "), C_NUM);
			}
			else
			{
				OnPain_str[1] = _T("차량 접근 없음        ");
			}
			Invalidate(false);
			OnPain_str[2].Format(_T("도로위 사람 수 : %d        "), H_NUM);
			t.od->run_flag = false;
		}
		else {
			boost::detail::Sleep(10);
		}

		m_result = m_image.clone();
		//imshow("result", m_result);
		waitKey(20);

		////////////////////////////////////////////////////////////////////////////
		if (OnTimerFlag == 1)
		{
			CClientDC dc(this);
			//Mat src = imread("image.jpg");
				  //int h = src.rows;
				  //int w = src.cols;
			int h = m_result.rows;
			int w = m_result.cols;

			uchar r = 0;
			uchar g = 0;
			uchar b = 0;

			CBitmap bitmap, rebitmap, rebitmap_Y;
			bitmap.LoadBitmap(IDB_BITMAP1);
			BITMAP bmpinfo;
			bitmap.GetBitmap(&bmpinfo);

			CDC memDC, rememDC, rememDC_Y;
			CBitmap *pOldBitmap;

			memDC.CreateCompatibleDC(&dc);
			rememDC.CreateCompatibleDC(&dc);
			rememDC_Y.CreateCompatibleDC(&dc);
			pOldBitmap = memDC.SelectObject(&bitmap);

			rebitmap.CreateCompatibleBitmap(&memDC, w, h);
			rebitmap_Y.CreateCompatibleBitmap(&memDC, w, h);
			rememDC.SelectObject(&rebitmap);
			rememDC_Y.SelectObject(&rebitmap_Y);

			BITMAP bm;
			rebitmap.GetObject(sizeof(BITMAP), (LPSTR)&bm);
			rebitmap_Y.GetObject(sizeof(BITMAP), (LPSTR)&bm);
			BYTE *pData = NULL;
			BYTE *pData_Y = NULL;
			pData = (BYTE*)malloc(bm.bmWidthBytes * bm.bmHeight);
			pData_Y = (BYTE*)malloc(bm.bmWidthBytes * bm.bmHeight);
			memset(pData, 0x00, bm.bmWidthBytes * bm.bmHeight);
			memset(pData_Y, 0x00, bm.bmWidthBytes * bm.bmHeight);
			rebitmap.GetBitmapBits(bm.bmWidthBytes * bm.bmHeight, pData);
			rebitmap_Y.GetBitmapBits(bm.bmWidthBytes * bm.bmHeight, pData_Y);
			RGBQUAD *pRgb = (RGBQUAD*)pData;
			RGBQUAD *pRgb_Y = (RGBQUAD*)pData_Y;

			for (int y = 0; y < bm.bmHeight; y++)
			{
				for (int x = 0; x < bm.bmWidth; x++)
				{
					int nPos = x + (y * bm.bmWidth);

					b = m_image.at<Vec3b>(y, x)[0];
					g = m_image.at<Vec3b>(y, x)[1];
					r = m_image.at<Vec3b>(y, x)[2];

					pRgb[nPos].rgbRed = r;
					pRgb[nPos].rgbGreen = g;
					pRgb[nPos].rgbBlue = b;

					b = m_result.at<Vec3b>(y, x)[0];
					g = m_result.at<Vec3b>(y, x)[1];
					r = m_result.at<Vec3b>(y, x)[2];

					pRgb_Y[nPos].rgbRed = r;
					pRgb_Y[nPos].rgbGreen = g;
					pRgb_Y[nPos].rgbBlue = b;
				}
			}

			rebitmap.SetBitmapBits(bm.bmWidthBytes * bm.bmHeight, pData);
			rebitmap_Y.SetBitmapBits(bm.bmWidthBytes * bm.bmHeight, pData_Y);

			free(pData);
			pData = NULL;
			free(pData_Y);
			pData_Y = NULL;

			dc.StretchBlt(20, 20, w, h, &rememDC, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);
			dc.StretchBlt(20, h + 40, w, h, &rememDC_Y, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);

			memDC.SelectObject(pOldBitmap);

			bitmap.DeleteObject();
			rebitmap.DeleteObject();
			rebitmap_Y.DeleteObject();
			memDC.DeleteDC();
			rememDC.DeleteDC();
			rememDC_Y.DeleteDC();
		}
		////////////////////////////////////////////////////////////////////////////
	}

	p1.join();
	p2.join();

	segment.deallocate(t.od->SIBimage[0]._pMem);
	segment.deallocate(t.od->SIBimage[1]._pMem);
	segment.deallocate(t.od);

	//std::cout << " Main End !" << std::endl;
	t.cam.vc.release();
}


void CChildView::OnFlieFinish()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
}


void CChildView::OnDisplayHuman()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	if(DISPLY_FLAG_HUMAN != TRUE) DISPLY_FLAG_HUMAN = TRUE;
	else DISPLY_FLAG_HUMAN = FALSE;
}


void CChildView::OnDisplayCar()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	if (DISPLY_FLAG_CAR != TRUE) DISPLY_FLAG_CAR = TRUE;
	else DISPLY_FLAG_CAR = FALSE;
}


void CChildView::OnDisplayVoice()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다
	DISPLY_FLAG_VOICE = TRUE;
	if (DISPLY_FLAG_VOICE != TRUE) DISPLY_FLAG_VOICE = TRUE;
	else DISPLY_FLAG_VOICE = FALSE;
}



void CChildView::OnDisplayLighttimer()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	if (DISPLY_FLAG_LIGHTTIMER != TRUE) DISPLY_FLAG_LIGHTTIMER = TRUE;
	else DISPLY_FLAG_LIGHTTIMER = FALSE;
}

void CChildView::OnUpdateDisplayCar(CCmdUI *pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(DISPLY_FLAG_CAR == TRUE);
}


void CChildView::OnUpdateDisplayHuman(CCmdUI *pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다
	pCmdUI->SetCheck(DISPLY_FLAG_HUMAN == TRUE);
}


void CChildView::OnUpdateDisplayHumanCount(CCmdUI *pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(DISPLY_FLAG_HUMANCOUNT == TRUE);
}


void CChildView::OnUpdateDisplayLighttimer(CCmdUI *pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(DISPLY_FLAG_LIGHTTIMER == TRUE);
}


void CChildView::OnUpdateDisplayVoice(CCmdUI *pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(DISPLY_FLAG_VOICE == TRUE);
}


void CChildView::OnDisplayHumanCount()
{
	DISPLY_FLAG_HUMANCOUNT = TRUE;
	if (DISPLY_FLAG_HUMANCOUNT != TRUE) DISPLY_FLAG_HUMANCOUNT = TRUE;
	else DISPLY_FLAG_HUMANCOUNT = FALSE;
}
