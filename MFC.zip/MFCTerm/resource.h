﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// MFCTerm.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDD_FORMVIEW                    101
#define IDR_MAINFRAME                   128
#define IDR_MFCTermTYPE                 130
#define IDB_CAR                         312
#define IDB_STOP                        313
#define IDB_PERSON                      314
#define IDB_WALK                        315
#define IDB_BITMAP1                     316
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_FLIE_FINISH                  32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_HUMAN                        32777
#define ID_CAR                          32778
#define ID_VOICE                        32779
#define ID_DISPLAY_HUMAN                32780
#define ID_DISPLAY_CAR                  32781
#define ID_DISPLAY_VOICE                32782
#define ID_Menu                         32783
#define ID_DISPLAY_HUMAN_COUNT          32784
#define ID_Menu32785                    32785
#define ID_32786                        32786
#define ID_DISPLAY_LIGHTTIMER           32787

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        317
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
