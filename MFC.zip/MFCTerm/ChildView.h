﻿
// ChildView.h: CChildView 클래스의 인터페이스
//


#pragma once
#include <opencv2\opencv.hpp>
#include "SharedImageBuffer.h"

using namespace cv;
using namespace std;

// CChildView 창
class CChildView : public CWnd
{
	// 생성입니다.
public:
	CChildView();

	// 특성입니다.
public:

	// 작업입니다.
public:
	Mat m_image;
	Mat m_result;
	CButton m_pushbutton;
	int OnTimerFlag;
	// 재정의입니다.
protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	// 구현입니다.
public:
	virtual ~CChildView();

	// 생성된 메시지 맵 함수
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnFileOpen();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg int m_button;
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnFlieFinish();
	afx_msg void OnDisplayHuman();
	afx_msg void OnDisplayCar();
	afx_msg void OnDisplayVoice();
//	afx_msg void OnDisplayHumanCount();
	afx_msg void OnUpdateDisplayCar(CCmdUI *pCmdUI);
	afx_msg void OnUpdateDisplayHuman(CCmdUI *pCmdUI);
	afx_msg void OnUpdateDisplayHumanCount(CCmdUI *pCmdUI);
	afx_msg void OnDisplayLighttimer();
	afx_msg void OnUpdateDisplayLighttimer(CCmdUI *pCmdUI);
	afx_msg void OnUpdateDisplayVoice(CCmdUI *pCmdUI);
	afx_msg void OnDisplayHumanCount();
};

