﻿
// ChildView.h: CChildView 클래스의 인터페이스
//


#pragma once
#include <opencv2\opencv.hpp>
#include "SharedImageBuffer.h"

using namespace cv;
using namespace std;

// CChildView 창
class CChildView : public CWnd
{
	// 생성입니다.
public:
	CChildView();

	// 특성입니다.
public:

	// Button
	CButton m_pushbutton1;
	CButton m_pushbutton2;

	// FLAG
	BOOL R = FALSE;		// 일반 차량 신호등 
	BOOL Y = FALSE;
	BOOL B = FALSE;

	BOOL R1 = FALSE;	// 개신 차량 신호등
	BOOL Y1 = FALSE;
	BOOL B1 = FALSE;

	BOOL Stop = FALSE;	//	일반 보행자 신호등
	BOOL Walk = FALSE;

	BOOL Stop1 = FALSE;	//	개선 보행자 신호등
	BOOL Walk1 = FALSE;

	BOOL Person = FALSE; 
	BOOL Car = FALSE; 
	BOOL Person1 = FALSE; // 개선 차량 신호등의 보행자 표시
	BOOL Car1 = FALSE; // 개선 보행자 신호등의 차량 표시

	BOOL DISPLY_FLAG_HUMAN = FALSE;		// 우측 정보창의 정보 표시
	BOOL DISPLY_FLAG_CAR = FALSE;
	BOOL DISPLY_FLAG_HUMANCOUNT = FALSE;
	BOOL DISPLY_FLAG_LIGHTTIMER = FALSE;
	BOOL DISPLY_FLAG_VOICE = FALSE;
	
	BOOL second_voice = TRUE; // 정규시간내 보행자가 건너지 못할 경우

	BOOL OnTimerFlag = TRUE;
	BOOL PlayFlag = FALSE;

	// LIGHT TIME
	INT last_time_T = 0; // 전체시간
	INT last_time_R = 0; // 정규시간
	INT last_time_A = 0; // 지연, 추가시간
	INT delay_time = 0;

	// IMAGE
	Mat m_image;
	Mat m_result;

	// STRING
	CString OnPain_str[11];	// 우측 정보출력용 문자열 배열
	CString OnPain_str2[3];

	// STRING INDEX
	INT DISPLAY_INDEX = 1; // 우측 정보출력용
	INT DISPLAY_INDEX_2 = 1;
	INT DISPLAY_INDEX_3 = 1;

	// OBJECT COUNT
	INT H_NUM = 0;
	INT C_NUM = 0;
	INT H_NUM_T = 0;	// TOTAL
	INT C_NUM_T = 0;

	// 작업입니다.
public:
	// 재정의입니다.
protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	// 구현입니다.
public:
	virtual ~CChildView();

	// 생성된 메시지 맵 함수
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnFileOpen();
	//afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg int m_button;
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnFlieFinish();
	afx_msg void OnDisplayHuman();
	afx_msg void OnDisplayCar();
	afx_msg void OnUpdateDisplayCar(CCmdUI *pCmdUI);
	afx_msg void OnUpdateDisplayHuman(CCmdUI *pCmdUI);
	afx_msg void OnUpdateDisplayHumanCount(CCmdUI *pCmdUI);
	afx_msg void OnDisplayLighttimer();
	afx_msg void OnUpdateDisplayLighttimer(CCmdUI *pCmdUI);
	afx_msg void OnDisplayHumanCount();
	void OnButtonClicked();
	void OnbuttonClicked1();
};

